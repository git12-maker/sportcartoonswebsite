vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Aug 2014 12:39:52 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{FDACAA4C-A038-409E-9F35-CA2F16ED46BC}
vti_cacheddtm:TX|26 Aug 2014 12:39:52 -0000
vti_filesize:IR|1890
vti_backlinkinfo:VX|
