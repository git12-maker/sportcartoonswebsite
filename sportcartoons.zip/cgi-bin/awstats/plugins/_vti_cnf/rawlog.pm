vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Aug 2014 12:39:52 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{2BCC10BE-050B-4200-82F2-F67FD463E62F}
vti_cacheddtm:TX|26 Aug 2014 12:39:52 -0000
vti_filesize:IR|4685
vti_backlinkinfo:VX|
