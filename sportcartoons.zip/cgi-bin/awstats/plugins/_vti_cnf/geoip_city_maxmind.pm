vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Aug 2014 12:39:52 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{1ACE587B-2DD6-4FD5-8CEE-C05E1025284A}
vti_cacheddtm:TX|26 Aug 2014 12:39:52 -0000
vti_filesize:IR|18286
vti_backlinkinfo:VX|
