vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Aug 2014 12:39:48 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{79A09545-D132-472C-BFBA-7894FA8BFCDA}
vti_cacheddtm:TX|26 Aug 2014 12:39:48 -0000
vti_filesize:IR|537696
vti_backlinkinfo:VX|
