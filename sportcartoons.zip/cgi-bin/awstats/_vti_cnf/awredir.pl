vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Aug 2014 12:39:48 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{1A5267BD-23DA-4CB4-AE4A-3392E76EF9A0}
vti_cacheddtm:TX|26 Aug 2014 12:39:48 -0000
vti_filesize:IR|5547
vti_backlinkinfo:VX|
